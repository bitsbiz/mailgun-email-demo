package com.bitsbiz;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class EmailDetails {

	private String toIds;

	private String subject;

	private String content;
	
	private Boolean isHtml;

}

package com.bitsbiz.service.impl;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.bitsbiz.service.EmailService;

import io.micrometer.core.instrument.util.StringUtils;

@Service
public class EmailServiceImpl implements EmailService {

	@Autowired
	private Environment environment;

	@Autowired
	private JavaMailSender mailSender;

	@Override
	public void sendEmailFromDirectory() throws IOException {

		String content = readFromFile();
		String subject = environment.getProperty("bitsbiz.smtp.email.subject");
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("dakshaoswal1205@gmail.com");
		Map<String, String[]> dataIds = new HashMap<String, String[]>();
		dataIds = getDataFromCSV();
		message.setTo(dataIds.get("toIds"));
		message.setTo(dataIds.get("ccIds"));
		message.setTo(dataIds.get("bccIds"));
		message.setSubject(subject);
		message.setText(content);
		mailSender.send(message);

	}

	private Map<String, String[]> getDataFromCSV() throws IOException {
		String file = environment.getProperty("bitsbiz.smtp.emailIds.file");
		Map<String, String[]> dataIds = new HashMap<String, String[]>();
		List<String> toIds = new ArrayList<String>();
		List<String> ccIds = new ArrayList<String>();
		List<String> bccIds = new ArrayList<String>();
		Reader reader = new FileReader(file);

		final CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader());
		for (CSVRecord record : parser.getRecords()) {
			String toId = record.get("toId");
			String ccId = record.get("ccId");
			String bccId = record.get("bccId");
			if (StringUtils.isNotBlank(toId)) {
				toIds.add(toId);
			}
			if (StringUtils.isNotBlank(ccId)) {
				ccIds.add(ccId);
			}
			if (StringUtils.isNotBlank(bccId)) {
				bccIds.add(bccId);
			}
		}

		String[] toItemsArray = new String[toIds.size()];
		String[] ccItemsArray = new String[ccIds.size()];
		String[] bccItemsArray = new String[bccIds.size()];

		dataIds.put("toIds", toIds.toArray(toItemsArray));
		dataIds.put("ccIds", ccIds.toArray(ccItemsArray));
		dataIds.put("bccIds", bccIds.toArray(bccItemsArray));
		return dataIds;
	}

	private String readFromFile() throws IOException {
		String content = "";
		String filePath = environment.getProperty("bitsbiz.smtp.email.content");
		File file = new File(filePath);
		content = FileUtils.readFileToString(file);
		return content;
	}

	@Override
	public void sendEmail(String toEmailId, String subject, String content) {

		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom("dakshaoswal1205@gmail.com");
		message.setTo(toEmailId.split(";"));
		message.setSubject(subject);
		message.setText(content);
		mailSender.send(message);

	}

	@Override
	public void sendHtmlEmail(String toEmailId, String subject, String content) throws MessagingException {
		MimeMessage mail = mailSender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(mail, true);
		mail.setHeader("Content-Type", "text/html");
		helper.setTo(toEmailId);
		helper.setSubject(subject);
		//helper.setText(content, "utf-8", "html");
		mail.setContent(content,  "text/html");
		mailSender.send(mail);

	}

}

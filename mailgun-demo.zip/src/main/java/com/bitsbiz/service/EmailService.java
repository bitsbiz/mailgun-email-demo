package com.bitsbiz.service;

import java.io.IOException;

import javax.mail.MessagingException;

public interface EmailService {
	
	public void sendEmailFromDirectory() throws IOException ;

	public void sendEmail(String toEmailId, String subject, String content);
	

	public void sendHtmlEmail(String toEmailId, String subject, String content) throws MessagingException;

}

package com.bitsbiz;

import java.io.IOException;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bitsbiz.service.EmailService;

@RestController
@RequestMapping(value = "/bitsbiz/")
public class EmailController {

	@Autowired
	private EmailService emailService;

	@RequestMapping(value = "email/", method = RequestMethod.POST)
	public void sendEmailFromDirectory() throws IOException {
		emailService.sendEmailFromDirectory();
	}

	@RequestMapping(value = "email-form/", method = RequestMethod.POST)
	public void sendEmail(@RequestBody EmailDetails emailDetails) throws IOException, MessagingException {
		String toEmailId = emailDetails.getToIds();
		String subject = emailDetails.getSubject();
		String content = emailDetails.getContent();
		boolean isHtml = emailDetails.getIsHtml();
		if (Boolean.TRUE.equals(isHtml)) {
			emailService.sendHtmlEmail(toEmailId, subject, content);
		} else {
			emailService.sendEmail(toEmailId, subject, content);
		}
	}
}

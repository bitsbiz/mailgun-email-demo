package com.bitsbiz.mailgundemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailgunDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
